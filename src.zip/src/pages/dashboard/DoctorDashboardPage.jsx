import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  CalendarDays,
  Users,
  Video,
  Clock3,
  BadgeCheck,
  RefreshCcw,
  Building2,
} from "lucide-react";
import ClinicComboBox from "../../components/ClinicComboBox";
import { useAuth } from "../../contexts/AuthContext";
import {
  getDoctorDashboard,
  getDoctorCalendarStatus,
} from "../../api/dashboardApi";

function StatCard({ title, value, icon: Icon, color = "#2563eb", onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        border: "1px solid #e2e8f0",
        background: "#fff",
        borderRadius: 16,
        padding: 20,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 16,
        width: "100%",
        cursor: onClick ? "pointer" : "default",
        boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
      }}
    >
      <div style={{ textAlign: "left" }}>
        <div
          style={{
            fontSize: 14,
            color: "#64748b",
            marginBottom: 8,
            fontWeight: 500,
          }}
        >
          {title}
        </div>
        <div
          style={{
            fontSize: 28,
            fontWeight: 700,
            color: "#0f172a",
          }}
        >
          {value ?? 0}
        </div>
      </div>

      <div
        style={{
          width: 52,
          height: 52,
          minWidth: 52,
          borderRadius: 14,
          background: `${color}15`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon size={24} color={color} />
      </div>
    </button>
  );
}

function SectionCard({ title, children, action }) {
  return (
    <div
      style={{
        border: "1px solid #e2e8f0",
        background: "#fff",
        borderRadius: 16,
        padding: 20,
        boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          marginBottom: 16,
        }}
      >
        <h3
          style={{
            margin: 0,
            fontSize: 18,
            fontWeight: 700,
            color: "#0f172a",
          }}
        >
          {title}
        </h3>
        {action}
      </div>
      {children}
    </div>
  );
}

const quickActionStyle = {
  border: "1px solid #e2e8f0",
  background: "#fff",
  borderRadius: 12,
  padding: "14px 16px",
  fontWeight: 700,
  color: "#0f172a",
  cursor: "pointer",
  textAlign: "left",
};

export default function DoctorDashboardPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const [dashboard, setDashboard] = useState(null);
  const [calendarStatus, setCalendarStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [calendarLoading, setCalendarLoading] = useState(false);
  const [error, setError] = useState("");

  const clinicOptions = useMemo(() => {
    const rows = user?.doctor_clinics || user?.clinics || [];

    const mapped = rows
      .filter((item) => item && (item.is_active === undefined || Number(item.is_active) === 1))
      .map((item) => ({
        id: String(item.clinic_id),
        title: item.clinic_title,
      }));

    return mapped.length > 1
      ? [{ id: "all", title: "All" }, ...mapped]
      : mapped;
  }, [user]);

  const [selectedClinic, setSelectedClinic] = useState({ id: "all", title: "All" });

  useEffect(() => {
    if (!clinicOptions.length) return;

    const currentId = String(selectedClinic?.id || "");
    const exists = clinicOptions.some((item) => String(item.id) === currentId);

    if (!exists) {
      setSelectedClinic(clinicOptions[0]);
    }
  }, [clinicOptions, selectedClinic]);

  const currentClinicId =
    selectedClinic?.id && selectedClinic.id !== "all" ? selectedClinic.id : "";

  async function loadCalendarStatus(clinicId = "") {
    setCalendarLoading(true);

    try {
      const res =
        clinicId && clinicId !== "all"
          ? await getDoctorCalendarStatus(clinicId)
          : await getDoctorCalendarStatus();

      console.log("DOCTOR_CALENDAR_STATUS =", res);
      setCalendarStatus(res || null);
    } catch (err) {
      console.error("loadCalendarStatus error =", err);
      setCalendarStatus(null);
    } finally {
      setCalendarLoading(false);
    }
  }

  async function loadData(clinicId = "") {
    setLoading(true);
    setError("");

    try {
      const dashboardRes =
        clinicId && clinicId !== "all"
          ? await getDoctorDashboard(clinicId)
          : await getDoctorDashboard();

      console.log("DOCTOR_DASHBOARD_RESPONSE =", dashboardRes);

      await loadCalendarStatus(clinicId);
      setDashboard(dashboardRes || null);
    } catch (err) {
      console.error("loadData error =", err);
      setError(err?.response?.data?.message || err?.message || "Could not load dashboard.");
      setDashboard(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData(currentClinicId);
  }, [currentClinicId]);

  const stats = dashboard?.data || dashboard?.stats || dashboard || {};

  const todayAppointments =
    stats?.today_appointments ??
    stats?.appointments_today ??
    stats?.todayAppointments ??
    0;

  const totalAppointments =
    stats?.total_appointments ??
    stats?.appointments_count ??
    stats?.totalAppointments ??
    0;

  const pendingAppointments =
    stats?.pending_appointments ??
    stats?.pendingAppointments ??
    0;

  const videoAppointments =
    stats?.video_appointments ??
    stats?.videoAppointments ??
    0;

  const completedAppointments =
    stats?.completed_appointments ??
    stats?.completedAppointments ??
    0;

  const calendarConnected =
    calendarStatus?.data?.connected ??
    calendarStatus?.connected ??
    dashboard?.calendar_connected ??
    false;

  const selectedClinicTitle =
    selectedClinic?.title ||
    clinicOptions?.find((item) => item.id === currentClinicId)?.title ||
    "All";

  return (
    <div style={{ padding: 24 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: 16,
          flexWrap: "wrap",
          marginBottom: 20,
        }}
      >
        <div>
          <h1
            style={{
              margin: 0,
              fontSize: 28,
              fontWeight: 800,
              color: "#0f172a",
            }}
          >
            Dashboard
          </h1>
          <p
            style={{
              marginTop: 8,
              marginBottom: 0,
              color: "#64748b",
            }}
          >
            Overview of your appointments and consultations.
          </p>
        </div>

        <div style={{ minWidth: 260, maxWidth: 320, width: "100%" }}>
          <ClinicComboBox
            data={clinicOptions}
            name="Clinic"
            defaultData={selectedClinic}
            setState={setSelectedClinic}
          />
        </div>
      </div>

      <div
        style={{
          marginBottom: 20,
          display: "flex",
          alignItems: "center",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "10px 14px",
            borderRadius: 999,
            background: "#eff6ff",
            color: "#1d4ed8",
            fontWeight: 600,
            fontSize: 14,
          }}
        >
          <Building2 size={16} />
          Clinic: {selectedClinicTitle}
        </div>

        <button
          type="button"
          onClick={() => loadData(currentClinicId)}
          style={{
            border: "1px solid #cbd5e1",
            background: "#fff",
            color: "#0f172a",
            borderRadius: 12,
            padding: "10px 14px",
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            cursor: "pointer",
            fontWeight: 600,
          }}
        >
          <RefreshCcw size={16} />
          Refresh
        </button>
      </div>

      {error ? (
        <div
          style={{
            marginBottom: 16,
            padding: 14,
            borderRadius: 12,
            background: "#fef2f2",
            color: "#b91c1c",
            border: "1px solid #fecaca",
          }}
        >
          {error}
        </div>
      ) : null}

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 16,
          marginBottom: 24,
        }}
      >
        <StatCard
          title="Today Appointments"
          value={loading ? "..." : todayAppointments}
          icon={CalendarDays}
          color="#2563eb"
          onClick={() => navigate("/appointments?filter=today")}
        />
        <StatCard
          title="Total Appointments"
          value={loading ? "..." : totalAppointments}
          icon={Users}
          color="#7c3aed"
          onClick={() => navigate("/appointments")}
        />
        <StatCard
          title="Pending"
          value={loading ? "..." : pendingAppointments}
          icon={Clock3}
          color="#ea580c"
          onClick={() => navigate("/appointments?status=Pending")}
        />
        <StatCard
          title="Video Consultations"
          value={loading ? "..." : videoAppointments}
          icon={Video}
          color="#0891b2"
          onClick={() => navigate("/appointments?type=Video Consultant")}
        />
        <StatCard
          title="Completed"
          value={loading ? "..." : completedAppointments}
          icon={BadgeCheck}
          color="#16a34a"
          onClick={() => navigate("/appointments?status=Completed")}
        />
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
          gap: 16,
        }}
      >
        <SectionCard
          title="Calendar Status"
          action={
            calendarLoading ? (
              <span style={{ color: "#64748b", fontSize: 14 }}>Loading...</span>
            ) : null
          }
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
              padding: 16,
              borderRadius: 14,
              background: calendarConnected ? "#ecfdf5" : "#fff7ed",
              border: `1px solid ${calendarConnected ? "#bbf7d0" : "#fed7aa"}`,
            }}
          >
            <div>
              <div
                style={{
                  fontWeight: 700,
                  color: "#0f172a",
                  marginBottom: 6,
                }}
              >
                {calendarConnected ? "Calendar Connected" : "Calendar Not Connected"}
              </div>
              <div style={{ color: "#64748b", fontSize: 14 }}>
                {calendarConnected
                  ? "Your Google Calendar integration is active."
                  : "Connect your calendar to sync appointments."}
              </div>
            </div>

            <div
              style={{
                padding: "8px 12px",
                borderRadius: 999,
                background: calendarConnected ? "#16a34a" : "#ea580c",
                color: "#fff",
                fontWeight: 700,
                fontSize: 12,
                whiteSpace: "nowrap",
              }}
            >
              {calendarConnected ? "Connected" : "Pending"}
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Quick Actions">
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
              gap: 12,
            }}
          >
            <button
              type="button"
              onClick={() => navigate("/appointments")}
              style={quickActionStyle}
            >
              View Appointments
            </button>

            <button
              type="button"
              onClick={() => navigate("/appointments?status=Pending")}
              style={quickActionStyle}
            >
              Pending Appointments
            </button>

            <button
              type="button"
              onClick={() => navigate("/profile")}
              style={quickActionStyle}
            >
              My Profile
            </button>

            <button
              type="button"
              onClick={() => loadData(currentClinicId)}
              style={quickActionStyle}
            >
              Reload Dashboard
            </button>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}