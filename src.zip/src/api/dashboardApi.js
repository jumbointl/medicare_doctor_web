import { GET } from "../Controllers/ApiControllers";
import { getAccessToken  } from "../utils/tokenStorage";

export async function getDoctorDashboard(clinicId = "") {
  const query =
    clinicId && clinicId !== "all"
      ? `doctor-web/dashboard?clinic_id=${clinicId}`
      : "doctor-web/dashboard";

  return await GET(getAccessToken(), query);
}

export async function getDoctorCalendarStatus(clinicId = "") {
  const query =
    clinicId && clinicId !== "all"
      ? `doctor-web/calendar-status?clinic_id=${clinicId}`
      : "doctor-web/calendar-status";

  return await GET(getAccessToken(), query);
}